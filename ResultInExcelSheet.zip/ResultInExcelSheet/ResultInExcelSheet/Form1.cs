﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;
using System.Globalization;

namespace ResultInExcelSheet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CultureInfo myCItrad = new CultureInfo(0x040A, false);
        }

        Thread thread1, thread2;

        private void R_ExcelSheet_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            //fdlg.InitialDirectory = @"D:\";
            fdlg.Filter = "Excel Files (*.xls*)|*.xlsx*|Excel Files (*.xls*)|*.xlsx*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = fdlg.FileName;
            }
        }

        private void ResultFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox1.Text = folderDlg.SelectedPath;
            }
        }

        private void FillExcel_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread1 = new Thread(() => ResultInExcel_Click(sender, e));
            thread1.Start();
        }

        public void ResultInExcel_Click(object sender, EventArgs e)
        {
            int j = 2,k = 1;
            button3.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            xlWorkBook = xlapp.Workbooks.Open(textBox2.Text);
            xlWorkSheet = xlWorkBook.ActiveSheet;

            string[] files = Directory.GetFiles(textBox1.Text);
            foreach (string file in files)
            {
                string name = file.Substring(file.LastIndexOf("\\") + 1);      
                if(file.Contains(".log"))
                {
                     List<string> AllLogLines = new List<string>();
                     string[] lines = System.IO.File.ReadAllLines((textBox1.Text + "\\" + name));
                     foreach (string line in lines)
                     {
                         AllLogLines.Add(line);
                     }                 

                     xlWorkSheet.Cells[j, 1] = name.Replace(".log" , "");

                     for (var i = 0; i < AllLogLines.Count; i++)
                     {
                         if (AllLogLines[i].Contains("Acceptance criteria"))
                         {
                             if (name.Contains("SW_DTC"))
                             {
                                 if (AllLogLines[i + 1].Contains("Passed"))
                                 {
                                     xlWorkSheet.Cells[j, ++k] = "p";
                                 }
                                 if (AllLogLines[i + 1].Contains("Failed"))
                                 {
                                     xlWorkSheet.Cells[j, ++k] = "Fail";
                                 }
                             }
                             else
                             {
                                 if (AllLogLines[i + 1].Contains("Tolerance"))
                                 {
                                     if (AllLogLines[i + 2].Contains("Passed"))
                                     {
                                         if (AllLogLines[i + 3].Contains("Acceptance criteria") || string.IsNullOrEmpty(AllLogLines[i + 3]))
                                         {
                                             xlWorkSheet.Cells[j, ++k] = "p";
                                         }
                                         if (AllLogLines[i + 3].Contains("Failed"))
                                         {
                                             string line = AllLogLines[i + 3];
                                             string temp1 = line.Substring((line.IndexOf("(", 0) + 1), 5);
                                             string temp2 = line.Substring((line.IndexOf("-", 0) + 1), 5);

                                             float a = float.Parse(temp1.Replace("-" , "0") , System.Globalization.CultureInfo.InvariantCulture);
                                             float b = float.Parse(temp2.Replace(")" , "0"), System.Globalization.CultureInfo.InvariantCulture);

                                             if ((b - a) < 0.5)
                                                 xlWorkSheet.Cells[j, ++k] = "p";
                                             else
                                                 xlWorkSheet.Cells[j, ++k] = "Fail";  
                                         }
                                     }
                                     if (AllLogLines[i + 2].Contains("Failed"))
                                     {
                                         xlWorkSheet.Cells[j, ++k] = "Fail";
                                     }
                                 }

                                 if (AllLogLines[i + 1].Contains("Passed"))
                                 {
                                     if (AllLogLines[i + 2].Contains("Acceptance criteria") || string.IsNullOrEmpty(AllLogLines[i + 2]))
                                     {
                                         xlWorkSheet.Cells[j, ++k] = "p";
                                     }
                                     if (AllLogLines[i + 2].Contains("Failed"))
                                     {
                                         string line = AllLogLines[i + 2];
                                         string temp1 = line.Substring((line.IndexOf("(", 0) + 1), 5);
                                         string temp2 = line.Substring((line.IndexOf("-", 0) + 1), 5);

                                         float a = float.Parse(temp1, System.Globalization.CultureInfo.InvariantCulture);
                                         float b = float.Parse(temp2, System.Globalization.CultureInfo.InvariantCulture);

                                         if ((b - a) < 0.5)
                                             xlWorkSheet.Cells[j, ++k] = "p";
                                         else
                                             xlWorkSheet.Cells[j, ++k] = "Fail";  
                                     }
                                 }

                                 if (AllLogLines[i + 1].Contains("Failed"))
                                 {
                                     xlWorkSheet.Cells[j, ++k] = "Fail";
                                 }
                             }
                         }
                     }
                     k = 1; j++;
                }
            }

            xlWorkBook.Save();
            xlWorkBook.Close();
            button3.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
            MessageBox.Show("Excel Sheet Updated");
            xlapp.Quit();
        }

        // // // // // // // //------------------------------------------------------

        private void DataBase_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            //fdlg.InitialDirectory = @"D:\";
            fdlg.Filter = "Excel Files (*.xls*)|*.xlsx*|Excel Files (*.xls*)|*.xlsx*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox4.Text = fdlg.FileName;
            }
        }

        private void FillingExcel_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            //fdlg.InitialDirectory = @"D:\";
            fdlg.Filter = "Excel Files (*.xls*)|*.xlsx*|Excel Files (*.xls*)|*.xlsx*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox3.Text = fdlg.FileName;
            }
        }

        private void Fill_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread2 = new Thread(() => DataInExcel_Click(sender, e));
            thread2.Start();
        }

        public void DataInExcel_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != string.Empty && textBox4.Text != string.Empty)
            {
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                Excel.Application xlapp = new Excel.Application();
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                xlWorkBook = xlapp.Workbooks.Open(textBox4.Text);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows_Data = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols_Data = xlWorkSheet.UsedRange.Columns.Count;

                Dictionary<string, string> AllDataBase = new Dictionary<string, string>();
                for (int s = 2; s <= iTotalRows_Data; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    string FailurePosition = (string)(xlWorkSheet.Cells[s, 2] as Excel.Range).Value2;
                    int i = 0;

                    if (string.IsNullOrEmpty(failureName) && string.IsNullOrEmpty(FailurePosition))
                        continue;

                    foreach (var key in AllDataBase.Keys)
                    {
                        if (AllDataBase.ContainsKey(failureName))
                        {
                            i = 1;
                            break;
                        }
                    }

                    if (i == 1)
                    {
                        i = 0;
                        continue;
                    }

                    AllDataBase.Add(failureName, FailurePosition);
                }

                xlWorkBook.Close();

                xlWorkBook = xlapp.Workbooks.Open(textBox3.Text);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols = xlWorkSheet.UsedRange.Columns.Count;

                for (int s = 2; s <= iTotalRows; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    string FailurePosition = (string)(xlWorkSheet.Cells[s, 2] as Excel.Range).Value2;
                    string failurePos = null;

                    if (!(string.IsNullOrEmpty(FailurePosition)))
                        continue;

                    if (string.IsNullOrEmpty(failureName))
                        continue;

                    foreach (var key in AllDataBase.Keys)
                    {
                        if (AllDataBase.ContainsKey(failureName))
                        {
                            failurePos = AllDataBase[failureName];
                            break;
                        }
                    }

                    if (failurePos != null)
                    {
                        xlWorkSheet.Cells[s, 2] = failurePos;
                    }
                    else { }
                }

                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                xlWorkBook.Save();
                xlWorkBook.Close();
                MessageBox.Show("Excle sheet is updated");
                xlapp.Quit();
            }
            else
                MessageBox.Show("Please select database and excle sheet whcich want to modify!");
        }

    }
}
