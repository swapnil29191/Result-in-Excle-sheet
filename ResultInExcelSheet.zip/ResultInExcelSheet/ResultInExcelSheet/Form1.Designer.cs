﻿namespace ResultInExcelSheet
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ResultInExcel = new System.Windows.Forms.TabPage();
            this.CollectData = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.ResultInExcel.SuspendLayout();
            this.CollectData.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(510, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Log Path";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ResultFolder_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(510, 55);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "ExcelSheet";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.R_ExcelSheet_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(213, 89);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 46);
            this.button3.TabIndex = 2;
            this.button3.Text = "Fill Excel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.FillExcel_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(21, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(472, 22);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(21, 62);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(472, 22);
            this.textBox2.TabIndex = 4;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ResultInExcel);
            this.tabControl1.Controls.Add(this.CollectData);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(643, 171);
            this.tabControl1.TabIndex = 5;
            // 
            // ResultInExcel
            // 
            this.ResultInExcel.BackColor = System.Drawing.Color.Transparent;
            this.ResultInExcel.Controls.Add(this.button1);
            this.ResultInExcel.Controls.Add(this.button3);
            this.ResultInExcel.Controls.Add(this.textBox2);
            this.ResultInExcel.Controls.Add(this.button2);
            this.ResultInExcel.Controls.Add(this.textBox1);
            this.ResultInExcel.Location = new System.Drawing.Point(4, 25);
            this.ResultInExcel.Name = "ResultInExcel";
            this.ResultInExcel.Padding = new System.Windows.Forms.Padding(3);
            this.ResultInExcel.Size = new System.Drawing.Size(635, 142);
            this.ResultInExcel.TabIndex = 0;
            this.ResultInExcel.Text = "ResultInExcel";
            // 
            // CollectData
            // 
            this.CollectData.BackColor = System.Drawing.Color.Transparent;
            this.CollectData.Controls.Add(this.button4);
            this.CollectData.Controls.Add(this.button5);
            this.CollectData.Controls.Add(this.textBox3);
            this.CollectData.Controls.Add(this.button6);
            this.CollectData.Controls.Add(this.textBox4);
            this.CollectData.Location = new System.Drawing.Point(4, 25);
            this.CollectData.Name = "CollectData";
            this.CollectData.Padding = new System.Windows.Forms.Padding(3);
            this.CollectData.Size = new System.Drawing.Size(635, 142);
            this.CollectData.TabIndex = 1;
            this.CollectData.Text = "CollectData";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(516, 16);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 36);
            this.button4.TabIndex = 5;
            this.button4.Text = "DataBase";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.DataBase_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(221, 93);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 46);
            this.button5.TabIndex = 7;
            this.button5.Text = "Fill Excel";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Fill_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(27, 65);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(472, 22);
            this.textBox3.TabIndex = 8;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(516, 58);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 36);
            this.button6.TabIndex = 6;
            this.button6.Text = "ExcelSheet";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.FillingExcel_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(27, 24);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(472, 22);
            this.textBox4.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 172);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.ResultInExcel.ResumeLayout(false);
            this.ResultInExcel.PerformLayout();
            this.CollectData.ResumeLayout(false);
            this.CollectData.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ResultInExcel;
        private System.Windows.Forms.TabPage CollectData;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox4;
    }
}

